import React from 'react';

const AudioInput = ({ setAudio }) => {
  return (
    <div>
      <input
        type="file"
        accept="audio/*"
        onChange={(e) => setAudio(e.target.files[0])}
      />
    </div>
  );
};

export default AudioInput;