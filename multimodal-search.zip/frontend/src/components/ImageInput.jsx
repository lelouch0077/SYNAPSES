import React from 'react';

const ImageInput = ({ setImage }) => {
  return (
    <div>
      <input
        type="file"
        accept="image/*"
        onChange={(e) => setImage(e.target.files[0])}
      />
    </div>
  );
};

export default ImageInput;