import React from 'react';

const TextInput = ({ setText }) => {
  return (
    <div>
      <input
        type="text"
        placeholder="Enter search text"
        onChange={(e) => setText(e.target.value)}
      />
    </div>
  );
};

export default TextInput;