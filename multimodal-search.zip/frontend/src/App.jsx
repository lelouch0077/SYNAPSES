import React, { useState } from 'react';
import axios from 'axios';
import ImageInput from './components/ImageInput';
import AudioInput from './components/AudioInput';
import TextInput from './components/TextInput';

const App = () => {
  const [results, setResults] = useState([]);
  const [text, setText] = useState("");
  const [image, setImage] = useState(null);
  const [audio, setAudio] = useState(null);

  const handleSearch = async () => {
    const formData = new FormData();
    if (text) formData.append('text', text);
    if (image) formData.append('image', image);
    if (audio) formData.append('audio', audio);

    try {
      const response = await axios.post('http://localhost:8000/search/', formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      });
      setResults(response.data.results);
    } catch (error) {
      console.error(error);
    }
  };

  return (
    <div>
      <h1>Multimodal Search Engine</h1>
      <TextInput setText={setText} />
      <ImageInput setImage={setImage} />
      <AudioInput setAudio={setAudio} />
      <button onClick={handleSearch}>Search</button>
      <div>
        <h2>Results</h2>
        {results.length > 0 ? (
          results.map((result, index) => (
            <div key={index}>
              <h3>{result.title}</h3>
              <p>{result.description}</p>
              <img src={result.image_url} alt={result.title} />
              <a href={result.product_link} target="_blank" rel="noopener noreferrer">View Product</a>
            </div>
          ))
        ) : (
          <p>No results found</p>
        )}
      </div>
    </div>
  );
};

export default App;