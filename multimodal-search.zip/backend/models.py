from sentence_transformers import SentenceTransformer
import whisper
from PIL import Image
import requests
from io import BytesIO
import torch
from transformers import DetrImageProcessor, DetrForObjectDetection

# Load sentence transformer for text input
text_model = SentenceTransformer('paraphrase-MiniLM-L6-v2')

# Load Whisper for audio transcription
whisper_model = whisper.load_model("base")

# Load image transformer (for object detection example)
image_processor = DetrImageProcessor.from_pretrained("facebook/detr-resnet-50")
image_model = DetrForObjectDetection.from_pretrained("facebook/detr-resnet-50")

def process_text_input(text):
    return text_model.encode(text)

def process_image_input(image_file):
    image = Image.open(image_file.file)
    # You can enhance this part to extract features from the image if needed
    image = image_processor(images=image, return_tensors="pt").pixel_values
    with torch.no_grad():
        outputs = image_model(image)
    return outputs

def process_audio_input(audio_file):
    audio = whisper.load_audio(audio_file.file)
    transcription = whisper_model.transcribe(audio)
    return transcription['text']