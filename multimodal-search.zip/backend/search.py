import pandas as pd

# Load the product database (CSV file)
df = pd.read_csv('data/products.csv')

def search_products(query_embedding):
    # For simplicity, this is a simple text-based search. You can enhance it to use embeddings for better matching.
    results = []
    for index, row in df.iterrows():
        # Check if text-based match exists (replace with more complex logic if needed)
        if query_embedding.lower() in row['title'].lower() or query_embedding.lower() in row['description'].lower():
            results.append({
                "title": row['title'],
                "description": row['description'],
                "image_url": row['image_url'],
                "product_link": row['product_link']
            })
    return results