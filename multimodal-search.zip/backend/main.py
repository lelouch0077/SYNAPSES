from fastapi import FastAPI, File, UploadFile
from pydantic import BaseModel
from typing import List, Optional
from .search import search_products
from .models import process_text_input, process_image_input, process_audio_input

app = FastAPI()

class SearchQuery(BaseModel):
    text: Optional[str] = None
    image: Optional[UploadFile] = None
    audio: Optional[UploadFile] = None

@app.post("/search/")
async def search(query: SearchQuery):
    search_results = []
    
    if query.text:
        search_results = search_products(process_text_input(query.text))
    elif query.image:
        search_results = search_products(process_image_input(query.image))
    elif query.audio:
        search_results = search_products(process_audio_input(query.audio))
    
    return {"results": search_results}